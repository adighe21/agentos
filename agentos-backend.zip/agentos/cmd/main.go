package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/yourusername/agentos/internal/middleware"
	"github.com/yourusername/agentos/internal/orchestrator"
	"github.com/yourusername/agentos/internal/rag"
	"go.uber.org/zap"
)

func main() {
	// Load .env
	_ = godotenv.Load()

	// Logger
	logger, _ := zap.NewProduction()
	defer logger.Sync()

	// Init RAG client (Pinecone)
	ragClient, err := rag.NewPineconeClient(rag.Config{
		APIKey:    requireEnv("PINECONE_API_KEY"),
		IndexHost: requireEnv("PINECONE_INDEX_HOST"),
		Namespace: getEnv("PINECONE_NAMESPACE", "agentos"),
	}, logger)
	if err != nil {
		logger.Fatal("failed to init Pinecone", zap.Error(err))
	}

	// Init Orchestrator
	orch := orchestrator.New(orchestrator.Config{
		AnthropicKey: requireEnv("ANTHROPIC_API_KEY"),
		OpenAIKey:    getEnv("OPENAI_API_KEY", ""),
		MaxWorkers:   8,
	}, ragClient, logger)

	// Gin router
	if os.Getenv("ENV") == "production" {
		gin.SetMode(gin.ReleaseMode)
	}
	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(middleware.Logger(logger))
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{getEnv("FRONTEND_URL", "http://localhost:3000"), "*"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Authorization"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	// ── Routes ──────────────────────────────────────────
	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "version": "1.0.0"})
	})

	api := r.Group("/api/v1")
	{
		// Agent routes
		agents := api.Group("/agents")
		{
			agents.POST("/run", middleware.Auth(), orch.HandleRunAgent)
			agents.GET("/status/:taskID", middleware.Auth(), orch.HandleTaskStatus)
			agents.GET("/list", orch.HandleListAgents)
		}

		// RAG routes
		knowledge := api.Group("/knowledge")
		knowledge.Use(middleware.Auth())
		{
			knowledge.POST("/ingest", ragClient.HandleIngest)
			knowledge.POST("/query", ragClient.HandleQuery)
			knowledge.DELETE("/document/:id", ragClient.HandleDelete)
		}

		// Orchestrator workflow routes
		workflows := api.Group("/workflows")
		workflows.Use(middleware.Auth())
		{
			workflows.POST("/", orch.HandleCreateWorkflow)
			workflows.GET("/:id", orch.HandleGetWorkflow)
			workflows.GET("/", orch.HandleListWorkflows)
		}
	}

	// ── Server ──────────────────────────────────────────
	port := getEnv("PORT", "8080")
	srv := &http.Server{
		Addr:         fmt.Sprintf(":%s", port),
		Handler:      r,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 120 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		logger.Info("AgentOS backend starting", zap.String("port", port))
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("server error", zap.Error(err))
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("shutting down...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	orch.Shutdown()
	srv.Shutdown(ctx)
	logger.Info("server stopped")
}

func requireEnv(key string) string {
	v := os.Getenv(key)
	if v == "" {
		panic(fmt.Sprintf("required env var %s is not set", key))
	}
	return v
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
