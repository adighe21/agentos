package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
	"github.com/yourusername/agentos/internal/config"
	"github.com/yourusername/agentos/internal/middleware"
	"github.com/yourusername/agentos/internal/orchestrator"
	"github.com/yourusername/agentos/internal/rag"
	"github.com/yourusername/agentos/pkg/llm"
	"go.uber.org/zap"

	"github.com/go-chi/chi/v5"
	chimw "github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"
	"github.com/go-chi/httprate"
)

func main() {
	// Load .env (ignored in production — Railway injects env vars directly)
	_ = godotenv.Load()

	// Logger
	logger, _ := zap.NewProduction()
	if os.Getenv("ENV") == "development" {
		logger, _ = zap.NewDevelopment()
	}
	defer logger.Sync()

	// Config
	cfg := config.Load()

	// Core services
	llmClient := llm.NewClient(cfg.AnthropicKey, cfg.OpenAIKey, logger)
	ragService := rag.NewService(cfg.PineconeKey, cfg.PineconeIndex, cfg.PineconeHost, llmClient, logger)
	orch := orchestrator.New(cfg, ragService, llmClient, logger)

	// Router
	r := chi.NewRouter()

	// Global middleware
	r.Use(chimw.RequestID)
	r.Use(chimw.RealIP)
	r.Use(chimw.Recoverer)
	r.Use(chimw.Timeout(90 * time.Second))
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   cfg.AllowedOrigins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type"},
		AllowCredentials: true,
	}))
	r.Use(httprate.LimitByIP(100, time.Minute)) // 100 req/min per IP
	r.Use(middleware.Logger(logger))

	// Routes
	r.Get("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","version":"%s"}`, cfg.Version)
	})

	// Public routes
	r.Post("/auth/token", middleware.IssueToken(cfg.JWTSecret))

	// Protected routes
	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(cfg.JWTSecret, logger))

		// Orchestrator — run a multi-agent workflow
		r.Post("/orchestrate", orch.HandleWorkflow)
		r.Get("/orchestrate/{workflowID}", orch.HandleWorkflowStatus)

		// RAG — upsert + query
		r.Post("/rag/upsert", ragService.HandleUpsert)
		r.Post("/rag/query", ragService.HandleQuery)
		r.Delete("/rag/namespace/{ns}", ragService.HandleDeleteNamespace)

		// Agents — direct invocation
		r.Post("/agents/{agentType}/run", orch.HandleDirectAgentRun)
		r.Get("/agents", orch.HandleListAgents)
	})

	// Start server
	srv := &http.Server{
		Addr:         ":" + cfg.Port,
		Handler:      r,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 90 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	go func() {
		logger.Info("AgentOS server starting", zap.String("port", cfg.Port), zap.String("env", cfg.Env))
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("server error", zap.Error(err))
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("Shutting down...")
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	srv.Shutdown(ctx)
	logger.Info("Server stopped")
}
