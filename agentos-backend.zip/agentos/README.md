# AgentOS Backend

Go microservice backend for the AgentOS AI Micro-Agent Platform.

## Stack
- **Language**: Go 1.22
- **Framework**: Gin
- **LLM**: Anthropic Claude API
- **RAG**: Pinecone vector database
- **Auth**: JWT (HS256)
- **Deploy**: Railway (primary) · Docker · Kubernetes

---

## Project Structure

```
agentos/
├── cmd/
│   └── main.go                  # Entry point, router setup
├── internal/
│   ├── agents/
│   │   └── registry.go          # All 6 agent implementations + registry
│   ├── middleware/
│   │   ├── auth.go              # JWT auth middleware
│   │   └── logger.go            # Request logger
│   ├── models/
│   │   └── models.go            # Shared types: Task, Workflow, Agent, RAGDocument
│   ├── orchestrator/
│   │   └── orchestrator.go      # Task queue, workflow chaining, async execution
│   └── rag/
│       └── rag.go               # Pinecone RAG: embed → retrieve → ingest
├── pkg/
│   ├── llm/
│   │   └── client.go            # Anthropic Claude HTTP client
│   └── pinecone/
│       └── client.go            # Pinecone REST client (upsert, query, delete)
├── deployments/
│   ├── kubernetes/
│   │   └── deployment.yaml      # K8s Deployment + Service + HPA
│   └── railway/
├── Dockerfile                   # Multi-stage, scratch final image
├── railway.toml                 # Railway deploy config
├── .env.example                 # All required env vars
└── go.mod
```

---

## API Endpoints

### Health
```
GET /health
```

### Agents
```
GET  /api/v1/agents/list              # List all available agents
POST /api/v1/agents/run               # Run a single agent task (async)
GET  /api/v1/agents/status/:taskID    # Poll task result
```

### Workflows (multi-agent chains)
```
POST /api/v1/workflows/               # Create + run a workflow
GET  /api/v1/workflows/:id            # Get workflow status + results
GET  /api/v1/workflows/               # List all workflows
```

### Knowledge (RAG)
```
POST   /api/v1/knowledge/ingest        # Ingest documents into Pinecone
POST   /api/v1/knowledge/query         # Semantic search
DELETE /api/v1/knowledge/document/:id  # Remove a document
```

---

## Quick Start

### 1. Clone & configure
```bash
git clone https://github.com/yourusername/agentos
cd agentos
cp .env.example .env
# Fill in your keys in .env
```

### 2. Run locally
```bash
go run ./cmd/main.go
```

### 3. Deploy to Railway
```bash
# Install Railway CLI
npm install -g @railway/cli
railway login
railway init
railway up
# Set env vars in Railway dashboard or:
railway variables set ANTHROPIC_API_KEY=sk-ant-...
railway variables set PINECONE_API_KEY=pcsk_...
railway variables set PINECONE_INDEX_HOST=your-index.svc.pinecone.io
railway variables set JWT_SECRET=your-secret
```

### 4. Deploy to Kubernetes
```bash
# Create secrets first
kubectl create secret generic agentos-secrets \
  --from-literal=anthropic-api-key=sk-ant-... \
  --from-literal=pinecone-api-key=pcsk_... \
  --from-literal=pinecone-index-host=your-index.svc.pinecone.io \
  --from-literal=jwt-secret=your-secret

kubectl apply -f deployments/kubernetes/deployment.yaml
```

---

## Example API Usage

### Run a Research Agent
```bash
curl -X POST https://your-railway-url/api/v1/agents/run \
  -H "Authorization: Bearer YOUR_JWT" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_type": "research",
    "input": "Analyze the competitive landscape of AI agent platforms in 2025",
    "use_rag": true
  }'
# Returns: { "task_id": "...", "status": "pending" }
```

### Poll for result
```bash
curl https://your-railway-url/api/v1/agents/status/TASK_ID \
  -H "Authorization: Bearer YOUR_JWT"
```

### Run a multi-agent workflow
```bash
curl -X POST https://your-railway-url/api/v1/workflows/ \
  -H "Authorization: Bearer YOUR_JWT" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Research + Summarize",
    "input": "Latest trends in autonomous AI agents",
    "steps": [
      { "agent_type": "research" },
      { "agent_type": "summarization" }
    ]
  }'
```

### Ingest documents into RAG
```bash
curl -X POST https://your-railway-url/api/v1/knowledge/ingest \
  -H "Authorization: Bearer YOUR_JWT" \
  -H "Content-Type: application/json" \
  -d '{
    "documents": [
      { "text": "AgentOS is a 7-layer AI agent platform...", "metadata": { "source": "docs" } }
    ]
  }'
```

---

## Generating a JWT (dev)
```go
// Use any JWT library with secret from JWT_SECRET env var
// Claims: { "sub": "user-id", "exp": unix_timestamp }
```

Or use [jwt.io](https://jwt.io) with your `JWT_SECRET` for testing.

---

## Connecting to the Frontend (Vercel)

Set this env var in your Vercel project:
```
NEXT_PUBLIC_API_URL=https://your-railway-app.up.railway.app
```

Then call the backend from your frontend:
```js
const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/agents/run`, {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ agent_type: 'research', input: query, use_rag: true })
})
```
