package pinecone

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

type Client struct {
	apiKey    string
	indexHost string
	namespace string
	httpCli   *http.Client
}

type Vector struct {
	ID       string            `json:"id"`
	Values   []float64         `json:"values"`
	Metadata map[string]string `json:"metadata,omitempty"`
}

type UpsertRequest struct {
	Vectors   []Vector `json:"vectors"`
	Namespace string   `json:"namespace,omitempty"`
}

type QueryRequest struct {
	Vector          []float64 `json:"vector"`
	TopK            int       `json:"topK"`
	Namespace       string    `json:"namespace,omitempty"`
	IncludeMetadata bool      `json:"includeMetadata"`
}

type Match struct {
	ID       string            `json:"id"`
	Score    float64           `json:"score"`
	Metadata map[string]string `json:"metadata,omitempty"`
}

type QueryResponse struct {
	Matches []Match `json:"matches"`
}

func New(apiKey, indexHost, namespace string) *Client {
	return &Client{
		apiKey:    apiKey,
		indexHost: indexHost,
		namespace: namespace,
		httpCli:   &http.Client{Timeout: 30 * time.Second},
	}
}

func (c *Client) Upsert(ctx context.Context, vectors []Vector) error {
	req := UpsertRequest{Vectors: vectors, Namespace: c.namespace}
	return c.post(ctx, "/vectors/upsert", req, nil)
}

func (c *Client) Query(ctx context.Context, embedding []float64, topK int) ([]Match, error) {
	req := QueryRequest{
		Vector:          embedding,
		TopK:            topK,
		Namespace:       c.namespace,
		IncludeMetadata: true,
	}
	var resp QueryResponse
	if err := c.post(ctx, "/query", req, &resp); err != nil {
		return nil, err
	}
	return resp.Matches, nil
}

func (c *Client) DeleteByID(ctx context.Context, id string) error {
	type deleteReq struct {
		IDs       []string `json:"ids"`
		Namespace string   `json:"namespace,omitempty"`
	}
	return c.post(ctx, "/vectors/delete", deleteReq{IDs: []string{id}, Namespace: c.namespace}, nil)
}

func (c *Client) post(ctx context.Context, path string, reqBody, respBody interface{}) error {
	b, _ := json.Marshal(reqBody)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		fmt.Sprintf("https://%s%s", c.indexHost, path), bytes.NewReader(b))
	if err != nil {
		return err
	}
	req.Header.Set("Api-Key", c.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpCli.Do(req)
	if err != nil {
		return fmt.Errorf("pinecone request: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		raw, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("pinecone %d: %s", resp.StatusCode, string(raw))
	}
	if respBody != nil {
		return json.NewDecoder(resp.Body).Decode(respBody)
	}
	return nil
}
