package shared

import (
	"os"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

var Log *zap.Logger

func InitLogger(service string) {
	env := os.Getenv("ENV")

	var cfg zap.Config
	if env == "production" {
		cfg = zap.NewProductionConfig()
	} else {
		cfg = zap.NewDevelopmentConfig()
		cfg.EncoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	}

	cfg.InitialFields = map[string]interface{}{
		"service": service,
	}

	var err error
	Log, err = cfg.Build()
	if err != nil {
		panic("failed to init logger: " + err.Error())
	}
}
