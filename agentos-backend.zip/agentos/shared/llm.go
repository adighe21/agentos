package shared

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

// LLMClient handles calls to Claude (Anthropic) and OpenAI.
type LLMClient struct {
	anthropicKey string
	openaiKey    string
	httpClient   *http.Client
}

func NewLLMClient() *LLMClient {
	return &LLMClient{
		anthropicKey: os.Getenv("ANTHROPIC_API_KEY"),
		openaiKey:    os.Getenv("OPENAI_API_KEY"),
		httpClient:   &http.Client{Timeout: 60 * time.Second},
	}
}

// Complete routes to the correct provider based on req.Model.
func (c *LLMClient) Complete(req LLMRequest) (*LLMResponse, error) {
	start := time.Now()

	// Build context block
	ctxBlock := ""
	if len(req.Context) > 0 {
		var sb strings.Builder
		sb.WriteString("\n\n<context>\n")
		for _, doc := range req.Context {
			sb.WriteString(fmt.Sprintf("<document id=%q score=%.2f>\n%s\n</document>\n", doc.ID, doc.Score, doc.Text))
		}
		sb.WriteString("</context>\n")
		ctxBlock = sb.String()
	}

	fullPrompt := req.UserPrompt + ctxBlock

	var content string
	var tokens int
	var err error

	switch req.Model {
	case "gpt-4", "gpt-4o":
		content, tokens, err = c.callOpenAI(req.SystemPrompt, fullPrompt, req.Model, req.MaxTokens)
	default:
		// Default to Claude
		content, tokens, err = c.callClaude(req.SystemPrompt, fullPrompt, req.MaxTokens)
	}

	if err != nil {
		return nil, err
	}

	return &LLMResponse{
		Content: content,
		Model:   req.Model,
		Tokens:  tokens,
		Latency: time.Since(start).Milliseconds(),
	}, nil
}

// ─── Anthropic ────────────────────────────────────────────────────────────────

type anthropicRequest struct {
	Model     string             `json:"model"`
	MaxTokens int                `json:"max_tokens"`
	System    string             `json:"system,omitempty"`
	Messages  []anthropicMessage `json:"messages"`
}

type anthropicMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type anthropicResponse struct {
	Content []struct {
		Text string `json:"text"`
	} `json:"content"`
	Usage struct {
		InputTokens  int `json:"input_tokens"`
		OutputTokens int `json:"output_tokens"`
	} `json:"usage"`
}

func (c *LLMClient) callClaude(system, prompt string, maxTokens int) (string, int, error) {
	if maxTokens == 0 {
		maxTokens = 1024
	}
	payload := anthropicRequest{
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: maxTokens,
		System:    system,
		Messages:  []anthropicMessage{{Role: "user", Content: prompt}},
	}

	body, _ := json.Marshal(payload)
	req, _ := http.NewRequest("POST", "https://api.anthropic.com/v1/messages", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", c.anthropicKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", 0, fmt.Errorf("anthropic request failed: %w", err)
	}
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return "", 0, fmt.Errorf("anthropic error %d: %s", resp.StatusCode, string(raw))
	}

	var ar anthropicResponse
	if err := json.Unmarshal(raw, &ar); err != nil {
		return "", 0, fmt.Errorf("anthropic parse error: %w", err)
	}
	if len(ar.Content) == 0 {
		return "", 0, fmt.Errorf("anthropic: empty content")
	}

	total := ar.Usage.InputTokens + ar.Usage.OutputTokens
	return ar.Content[0].Text, total, nil
}

// ─── OpenAI ───────────────────────────────────────────────────────────────────

type openAIRequest struct {
	Model     string          `json:"model"`
	MaxTokens int             `json:"max_tokens"`
	Messages  []openAIMessage `json:"messages"`
}

type openAIMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type openAIResponse struct {
	Choices []struct {
		Message struct {
			Content string `json:"content"`
		} `json:"message"`
	} `json:"choices"`
	Usage struct {
		TotalTokens int `json:"total_tokens"`
	} `json:"usage"`
}

func (c *LLMClient) callOpenAI(system, prompt, model string, maxTokens int) (string, int, error) {
	if maxTokens == 0 {
		maxTokens = 1024
	}
	msgs := []openAIMessage{}
	if system != "" {
		msgs = append(msgs, openAIMessage{Role: "system", Content: system})
	}
	msgs = append(msgs, openAIMessage{Role: "user", Content: prompt})

	payload := openAIRequest{Model: model, MaxTokens: maxTokens, Messages: msgs}
	body, _ := json.Marshal(payload)

	req, _ := http.NewRequest("POST", "https://api.openai.com/v1/chat/completions", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+c.openaiKey)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", 0, fmt.Errorf("openai request failed: %w", err)
	}
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return "", 0, fmt.Errorf("openai error %d: %s", resp.StatusCode, string(raw))
	}

	var or openAIResponse
	if err := json.Unmarshal(raw, &or); err != nil {
		return "", 0, fmt.Errorf("openai parse error: %w", err)
	}
	if len(or.Choices) == 0 {
		return "", 0, fmt.Errorf("openai: empty choices")
	}

	return or.Choices[0].Message.Content, or.Usage.TotalTokens, nil
}
