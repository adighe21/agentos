package shared

import "time"

// ─── Agent Task ───────────────────────────────────────────────────────────────

type AgentType string

const (
	AgentResearch  AgentType = "research"
	AgentEmail     AgentType = "email"
	AgentFinance   AgentType = "finance"
	AgentData      AgentType = "data"
	AgentMatching  AgentType = "matching"
)

type TaskStatus string

const (
	TaskPending    TaskStatus = "pending"
	TaskRunning    TaskStatus = "running"
	TaskComplete   TaskStatus = "complete"
	TaskFailed     TaskStatus = "failed"
)

// Task is the unit of work passed between orchestrator and agents via Kafka.
type Task struct {
	ID          string            `json:"id"`
	AgentType   AgentType         `json:"agent_type"`
	Prompt      string            `json:"prompt"`
	Context     []RAGDocument     `json:"context,omitempty"`
	Metadata    map[string]string `json:"metadata,omitempty"`
	Status      TaskStatus        `json:"status"`
	Result      string            `json:"result,omitempty"`
	Error       string            `json:"error,omitempty"`
	CreatedAt   time.Time         `json:"created_at"`
	CompletedAt *time.Time        `json:"completed_at,omitempty"`
}

// ─── RAG ──────────────────────────────────────────────────────────────────────

type RAGDocument struct {
	ID       string            `json:"id"`
	Text     string            `json:"text"`
	Score    float32           `json:"score"`
	Metadata map[string]string `json:"metadata,omitempty"`
}

type RAGQueryRequest struct {
	Query     string            `json:"query"`
	Namespace string            `json:"namespace"`
	TopK      int               `json:"top_k"`
	Filter    map[string]string `json:"filter,omitempty"`
}

type RAGQueryResponse struct {
	Documents []RAGDocument `json:"documents"`
	Latency   int64         `json:"latency_ms"`
}

type RAGUpsertRequest struct {
	Namespace string        `json:"namespace"`
	Documents []RAGDocument `json:"documents"`
}

// ─── Orchestrator ─────────────────────────────────────────────────────────────

type WorkflowRequest struct {
	UserPrompt string            `json:"user_prompt"`
	Agents     []AgentType       `json:"agents,omitempty"` // if empty, orchestrator decides
	Metadata   map[string]string `json:"metadata,omitempty"`
}

type WorkflowResponse struct {
	WorkflowID string            `json:"workflow_id"`
	Tasks      []Task            `json:"tasks"`
	Status     TaskStatus        `json:"status"`
	Summary    string            `json:"summary,omitempty"`
	CreatedAt  time.Time         `json:"created_at"`
}

// ─── LLM ──────────────────────────────────────────────────────────────────────

type LLMRequest struct {
	SystemPrompt string        `json:"system_prompt"`
	UserPrompt   string        `json:"user_prompt"`
	Context      []RAGDocument `json:"context,omitempty"`
	MaxTokens    int           `json:"max_tokens"`
	Model        string        `json:"model"` // "claude" | "gpt-4"
}

type LLMResponse struct {
	Content  string `json:"content"`
	Model    string `json:"model"`
	Tokens   int    `json:"tokens"`
	Latency  int64  `json:"latency_ms"`
}

// ─── API ──────────────────────────────────────────────────────────────────────

type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

func OK(data interface{}) APIResponse {
	return APIResponse{Success: true, Data: data}
}

func Fail(err string) APIResponse {
	return APIResponse{Success: false, Error: err}
}
