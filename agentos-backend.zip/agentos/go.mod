module github.com/yourusername/agentos

go 1.22

require (
	github.com/gin-gonic/gin v1.10.0
	github.com/gin-contrib/cors v1.7.2
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/google/uuid v1.6.0
	github.com/joho/godotenv v1.5.1
	github.com/redis/go-redis/v9 v9.5.1
	github.com/segmentio/kafka-go v0.4.47
	go.uber.org/zap v1.27.0
	golang.org/x/sync v0.7.0
)
