package agents

import (
	"context"
	"fmt"
	"strings"

	"github.com/yourusername/agentos/internal/models"
	"github.com/yourusername/agentos/pkg/llm"
)

// ─── AgentRunner interface ────────────────────────────────────────────────────

type Runner interface {
	Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error)
}

// ─── Registry ─────────────────────────────────────────────────────────────────

var registry = map[models.AgentType]Runner{
	models.AgentResearch: &ResearchAgent{},
	models.AgentEmail:    &EmailAgent{},
	models.AgentFinance:  &FinanceAgent{},
	models.AgentData:     &DataAgent{},
	models.AgentSummary:  &SummaryAgent{},
	models.AgentMatching: &MatchingAgent{},
}

func Get(t models.AgentType) (Runner, error) {
	r, ok := registry[t]
	if !ok {
		return nil, fmt.Errorf("unknown agent type: %s", t)
	}
	return r, nil
}

func List() []models.Agent {
	return []models.Agent{
		{ID: "research-001", Name: "Research Agent", Type: models.AgentResearch, Status: "running", MaxPods: 10,
			Description: "Searches, scrapes, and synthesizes knowledge on any topic using RAG + LLM.",
			Plugins:     []string{"Tavily Search", "Pinecone RAG", "Web Scraper"},
			Pipeline:    []string{"Receive Query", "Vector Search", "Fetch Docs", "LLM Synthesis", "Return Report"}},
		{ID: "email-001", Name: "Email Agent", Type: models.AgentEmail, Status: "running", MaxPods: 3,
			Description: "Reads, drafts, categorizes and sends emails autonomously.",
			Plugins:     []string{"Gmail API", "SendGrid", "NLP Classifier"},
			Pipeline:    []string{"Parse Intent", "Compose Draft", "Review Context", "Send/Queue", "Log Event"}},
		{ID: "finance-001", Name: "Finance Agent", Type: models.AgentFinance, Status: "running", MaxPods: 5,
			Description: "Market analysis, portfolio alerts, financial reporting.",
			Plugins:     []string{"Alpha Vantage", "Yahoo Finance", "Stripe API"},
			Pipeline:    []string{"Fetch Market Data", "Run Analysis", "RAG Context", "Generate Insight", "Alert/Report"}},
		{ID: "data-001", Name: "Data Pipeline Agent", Type: models.AgentData, Status: "running", MaxPods: 7,
			Description: "ETL pipelines, data cleaning, ML feature engineering.",
			Plugins:     []string{"Apache Kafka", "Airflow", "Kubeflow"},
			Pipeline:    []string{"Ingest Source", "Transform", "Validate Schema", "Load to DB", "Trigger ML Run"}},
		{ID: "summary-001", Name: "Summarization Agent", Type: models.AgentSummary, Status: "running", MaxPods: 4,
			Description: "Condenses long documents, threads, and reports into actionable summaries.",
			Plugins:     []string{"Claude API", "PDF Parser"},
			Pipeline:    []string{"Receive Document", "Chunk Text", "Embed Chunks", "Summarize", "Return Summary"}},
		{ID: "matching-001", Name: "Matching Agent", Type: models.AgentMatching, Status: "idle", MaxPods: 4,
			Description: "Semantic matching, recommendation, compatibility scoring.",
			Plugins:     []string{"Weaviate VectorDB", "OpenAI Embeddings", "Profile API"},
			Pipeline:    []string{"Embed Profile", "Cosine Search", "Score Matches", "Rank Results", "Return List"}},
	}
}

// ─── Agent Implementations ────────────────────────────────────────────────────

type ResearchAgent struct{}

func (a *ResearchAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are a world-class research agent. Your job is to produce comprehensive, accurate, and well-structured research reports.
When given retrieved knowledge context, prioritize it alongside your training knowledge.
Always cite key facts, structure your output with clear sections, and be specific.`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

type EmailAgent struct{}

func (a *EmailAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are an expert email drafting agent. Write clear, professional, and context-appropriate emails.
Match tone to context: formal for business, warm for personal. Include subject line.
Format: Subject: [subject]\n\n[body]`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

type FinanceAgent struct{}

func (a *FinanceAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are a senior financial analyst agent. Provide rigorous, data-driven financial analysis.
Structure your reports with: Executive Summary, Key Metrics, Risk Factors, and Recommendations.
Always note when data is estimated vs factual. Never give direct investment advice without caveats.`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

type DataAgent struct{}

func (a *DataAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are a data engineering agent specializing in ETL pipelines, data modeling, and ML feature engineering.
Output clean, production-ready code or pipeline specifications. Prefer Python/SQL unless specified otherwise.
Include schema definitions, transformation logic, and validation steps.`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

type SummaryAgent struct{}

func (a *SummaryAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are a summarization agent. Distill content into clear, structured summaries.
Format: TL;DR (2 sentences) → Key Points (bullets) → Full Summary.
Preserve all critical facts, numbers, and named entities.`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

type MatchingAgent struct{}

func (a *MatchingAgent) Run(ctx context.Context, task *models.Task, ragContext string, client *llm.AnthropicClient) (string, error) {
	system := `You are a semantic matching and recommendation agent. Analyze compatibility between profiles, items, or concepts.
Output ranked matches with compatibility scores (0-100) and reasoning for each match.
Be specific about why items are compatible or incompatible.`
	prompt := buildPrompt(task.Input, ragContext)
	return client.Complete(ctx, system, prompt)
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

func buildPrompt(input, ragContext string) string {
	if ragContext == "" {
		return input
	}
	var sb strings.Builder
	sb.WriteString(ragContext)
	sb.WriteString("\n---\nUSER REQUEST:\n")
	sb.WriteString(input)
	return sb.String()
}
