package agents

import (
	"context"
	"fmt"
	"strings"

	"github.com/yourusername/agentos/internal/models"
	"github.com/yourusername/agentos/internal/rag"
	"github.com/yourusername/agentos/pkg/llm"
	"go.uber.org/zap"
)

// Agent is the interface every micro-agent must implement
type Agent interface {
	Type() models.AgentType
	Run(ctx context.Context, input string, ragContext string) (string, error)
}

// ── Registry ──────────────────────────────────────────────────────────────────

type Registry struct {
	agents map[models.AgentType]Agent
}

func NewRegistry(llmClient *llm.Client, ragSvc *rag.Service, log *zap.Logger) *Registry {
	r := &Registry{agents: make(map[models.AgentType]Agent)}
	r.Register(NewResearchAgent(llmClient, ragSvc, log))
	r.Register(NewSummarizationAgent(llmClient, log))
	r.Register(NewEmailAgent(llmClient, log))
	r.Register(NewFinanceAgent(llmClient, ragSvc, log))
	return r
}

func (r *Registry) Register(a Agent) {
	r.agents[a.Type()] = a
}

func (r *Registry) Get(t models.AgentType) (Agent, bool) {
	a, ok := r.agents[t]
	return a, ok
}

func (r *Registry) List() []models.AgentInfo {
	infos := []models.AgentInfo{}
	pods := map[models.AgentType]int{
		models.AgentResearch: 10,
		models.AgentSummary:  4,
		models.AgentEmail:    3,
		models.AgentFinance:  5,
	}
	for t := range r.agents {
		infos = append(infos, models.AgentInfo{
			Type:   t,
			Name:   strings.Title(string(t)) + " Agent",
			Status: "running",
			Pods:   pods[t],
		})
	}
	return infos
}

// ── Research Agent ────────────────────────────────────────────────────────────

type ResearchAgent struct {
	llm *llm.Client
	rag *rag.Service
	log *zap.Logger
}

func NewResearchAgent(l *llm.Client, r *rag.Service, log *zap.Logger) *ResearchAgent {
	return &ResearchAgent{llm: l, rag: r, log: log}
}

func (a *ResearchAgent) Type() models.AgentType { return models.AgentResearch }

func (a *ResearchAgent) Run(ctx context.Context, input string, ragContext string) (string, error) {
	system := `You are an elite research analyst. Your job is to produce comprehensive, 
well-structured research reports. Use the provided RAG context as your primary source.
Format your output with: Executive Summary, Key Findings (3-5 bullet points), 
Detailed Analysis, and Recommendations. Be specific and cite context where possible.`

	prompt := fmt.Sprintf("Research task: %s\n\nAvailable context:\n%s", input, ragContext)
	return a.llm.Complete(ctx, system, prompt)
}

// ── Summarization Agent ───────────────────────────────────────────────────────

type SummarizationAgent struct {
	llm *llm.Client
	log *zap.Logger
}

func NewSummarizationAgent(l *llm.Client, log *zap.Logger) *SummarizationAgent {
	return &SummarizationAgent{llm: l, log: log}
}

func (a *SummarizationAgent) Type() models.AgentType { return models.AgentSummary }

func (a *SummarizationAgent) Run(ctx context.Context, input string, ragContext string) (string, error) {
	system := `You are a precise summarization engine. Produce a clean, structured summary 
that preserves all critical information while reducing length by 70%. 
Use: TL;DR (1 sentence), Key Points (bullets), and a short Conclusion.`

	prompt := fmt.Sprintf("Summarize the following:\n\n%s\n\nAdditional context:\n%s", input, ragContext)
	return a.llm.Complete(ctx, system, prompt)
}

// ── Email Agent ───────────────────────────────────────────────────────────────

type EmailAgent struct {
	llm *llm.Client
	log *zap.Logger
}

func NewEmailAgent(l *llm.Client, log *zap.Logger) *EmailAgent {
	return &EmailAgent{llm: l, log: log}
}

func (a *EmailAgent) Type() models.AgentType { return models.AgentEmail }

func (a *EmailAgent) Run(ctx context.Context, input string, ragContext string) (string, error) {
	system := `You are a professional email writing assistant. Produce a well-structured email 
based on the intent provided. Include: Subject line, greeting, body paragraphs, 
call to action, and sign-off. Match the tone to the context (formal/casual).`

	prompt := fmt.Sprintf("Email intent: %s\n\nContext / prior conversation:\n%s", input, ragContext)
	return a.llm.Complete(ctx, system, prompt)
}

// ── Finance Agent ─────────────────────────────────────────────────────────────

type FinanceAgent struct {
	llm *llm.Client
	rag *rag.Service
	log *zap.Logger
}

func NewFinanceAgent(l *llm.Client, r *rag.Service, log *zap.Logger) *FinanceAgent {
	return &FinanceAgent{llm: l, rag: r, log: log}
}

func (a *FinanceAgent) Type() models.AgentType { return models.AgentFinance }

func (a *FinanceAgent) Run(ctx context.Context, input string, ragContext string) (string, error) {
	system := `You are a professional financial analyst. Provide data-driven analysis 
with clear structure: Market Overview, Risk Assessment, Key Metrics, 
and Actionable Recommendations. Always note data limitations.`

	prompt := fmt.Sprintf("Financial task: %s\n\nFinancial data / context:\n%s", input, ragContext)
	return a.llm.Complete(ctx, system, prompt)
}
