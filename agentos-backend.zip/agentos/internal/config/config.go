package config

import (
	"os"
	"strings"
)

type Config struct {
	// Server
	Port    string
	Env     string
	Version string

	// Auth
	JWTSecret string

	// CORS
	AllowedOrigins []string

	// LLM
	AnthropicKey string
	OpenAIKey    string
	DefaultModel string

	// Pinecone (RAG)
	PineconeKey   string
	PineconeIndex string
	PineconeHost  string // e.g. https://your-index-host.pinecone.io

	// Kafka (optional — stubbed when not set)
	KafkaBrokers []string
	KafkaTopic   string

	// Redis (optional — for workflow state)
	RedisURL string
}

func Load() *Config {
	return &Config{
		Port:    getEnv("PORT", "8080"),
		Env:     getEnv("ENV", "production"),
		Version: getEnv("VERSION", "1.0.0"),

		JWTSecret: mustEnv("JWT_SECRET"),

		AllowedOrigins: strings.Split(getEnv("ALLOWED_ORIGINS", "http://localhost:3000"), ","),

		AnthropicKey: getEnv("ANTHROPIC_API_KEY", ""),
		OpenAIKey:    getEnv("OPENAI_API_KEY", ""),
		DefaultModel: getEnv("DEFAULT_MODEL", "claude-opus-4-6"),

		PineconeKey:   mustEnv("PINECONE_API_KEY"),
		PineconeIndex: getEnv("PINECONE_INDEX", "agentos"),
		PineconeHost:  mustEnv("PINECONE_HOST"),

		KafkaBrokers: strings.Split(getEnv("KAFKA_BROKERS", ""), ","),
		KafkaTopic:   getEnv("KAFKA_TOPIC", "agentos.tasks"),

		RedisURL: getEnv("REDIS_URL", ""),
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func mustEnv(key string) string {
	v := os.Getenv(key)
	if v == "" {
		panic("missing required env var: " + key)
	}
	return v
}
