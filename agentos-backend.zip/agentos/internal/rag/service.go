package rag

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/yourusername/agentos/internal/models"
	"github.com/yourusername/agentos/pkg/llm"
	"go.uber.org/zap"
)

// Service wraps Pinecone REST API v1
type Service struct {
	apiKey    string
	indexName string
	host      string // e.g. https://your-index-xxxx.pinecone.io
	llm       *llm.Client
	http      *http.Client
	log       *zap.Logger
}

func NewService(apiKey, indexName, host string, llmClient *llm.Client, log *zap.Logger) *Service {
	return &Service{
		apiKey:    apiKey,
		indexName: indexName,
		host:      strings.TrimRight(host, "/"),
		llm:       llmClient,
		http:      &http.Client{Timeout: 30 * time.Second},
		log:       log,
	}
}

// ── Core RAG Methods ──────────────────────────────────────────────────────────

// Upsert embeds documents and stores them in Pinecone
func (s *Service) Upsert(ctx context.Context, docs []models.Document, namespace string) error {
	type vector struct {
		ID       string            `json:"id"`
		Values   []float32         `json:"values"`
		Metadata map[string]string `json:"metadata"`
	}

	vectors := make([]vector, 0, len(docs))
	for _, doc := range docs {
		embedding, err := s.llm.Embed(ctx, doc.Text)
		if err != nil {
			return fmt.Errorf("embed doc %s: %w", doc.ID, err)
		}
		meta := doc.Metadata
		if meta == nil {
			meta = map[string]string{}
		}
		meta["text"] = doc.Text
		vectors = append(vectors, vector{ID: doc.ID, Values: embedding, Metadata: meta})
	}

	body := map[string]any{"vectors": vectors}
	if namespace != "" {
		body["namespace"] = namespace
	}

	_, err := s.call(ctx, "POST", "/vectors/upsert", body)
	return err
}

// Query retrieves top-K matches then synthesizes an answer via LLM
func (s *Service) Query(ctx context.Context, query, namespace string, topK int) (*models.QueryResponse, error) {
	if topK <= 0 {
		topK = 5
	}

	// Embed query
	embedding, err := s.llm.Embed(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("embed query: %w", err)
	}

	// Pinecone query
	reqBody := map[string]any{
		"vector":          embedding,
		"topK":            topK,
		"includeMetadata": true,
	}
	if namespace != "" {
		reqBody["namespace"] = namespace
	}

	raw, err := s.call(ctx, "POST", "/query", reqBody)
	if err != nil {
		return nil, err
	}

	// Parse matches
	var pineconeResp struct {
		Matches []struct {
			ID       string            `json:"id"`
			Score    float64           `json:"score"`
			Metadata map[string]string `json:"metadata"`
		} `json:"matches"`
	}
	if err := json.Unmarshal(raw, &pineconeResp); err != nil {
		return nil, fmt.Errorf("parse pinecone response: %w", err)
	}

	matches := make([]models.Match, 0, len(pineconeResp.Matches))
	var contextBuilder strings.Builder
	for i, m := range pineconeResp.Matches {
		text := m.Metadata["text"]
		matches = append(matches, models.Match{
			ID:       m.ID,
			Score:    m.Score,
			Text:     text,
			Metadata: m.Metadata,
		})
		fmt.Fprintf(&contextBuilder, "[Document %d (score %.3f)]:\n%s\n\n", i+1, m.Score, text)
	}

	// LLM synthesis over retrieved context
	systemPrompt := `You are a helpful AI assistant with access to retrieved documents. 
Answer the user's question using ONLY the provided context. 
If the context doesn't contain enough information, say so clearly.
Be concise and factual.`

	userPrompt := fmt.Sprintf("Context:\n%s\n\nQuestion: %s", contextBuilder.String(), query)
	answer, err := s.llm.Complete(ctx, systemPrompt, userPrompt)
	if err != nil {
		s.log.Warn("LLM synthesis failed", zap.Error(err))
		answer = "Retrieved documents found but synthesis failed."
	}

	return &models.QueryResponse{Matches: matches, Answer: answer}, nil
}

// DeleteNamespace removes all vectors in a Pinecone namespace
func (s *Service) DeleteNamespace(ctx context.Context, namespace string) error {
	body := map[string]any{"deleteAll": true, "namespace": namespace}
	_, err := s.call(ctx, "POST", "/vectors/delete", body)
	return err
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (s *Service) HandleUpsert(w http.ResponseWriter, r *http.Request) {
	var req models.UpsertRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || len(req.Documents) == 0 {
		writeError(w, "invalid request body — documents array required", http.StatusBadRequest)
		return
	}

	if err := s.Upsert(r.Context(), req.Documents, req.Namespace); err != nil {
		s.log.Error("upsert failed", zap.Error(err))
		writeError(w, err.Error(), http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"upserted": len(req.Documents),
		"namespace": req.Namespace,
	})
}

func (s *Service) HandleQuery(w http.ResponseWriter, r *http.Request) {
	var req models.QueryRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Query == "" {
		writeError(w, "invalid request body — query string required", http.StatusBadRequest)
		return
	}

	result, err := s.Query(r.Context(), req.Query, req.Namespace, req.TopK)
	if err != nil {
		s.log.Error("rag query failed", zap.Error(err))
		writeError(w, err.Error(), http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusOK, result)
}

func (s *Service) HandleDeleteNamespace(w http.ResponseWriter, r *http.Request) {
	ns := r.PathValue("ns")
	if ns == "" {
		writeError(w, "namespace required", http.StatusBadRequest)
		return
	}
	if err := s.DeleteNamespace(r.Context(), ns); err != nil {
		writeError(w, err.Error(), http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"deleted_namespace": ns})
}

// ── Pinecone HTTP helper ──────────────────────────────────────────────────────

func (s *Service) call(ctx context.Context, method, path string, body any) ([]byte, error) {
	raw, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}

	req, err := http.NewRequestWithContext(ctx, method, s.host+path, bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Api-Key", s.apiKey)

	resp, err := s.http.Do(req)
	if err != nil {
		return nil, fmt.Errorf("pinecone %s %s: %w", method, path, err)
	}
	defer resp.Body.Close()

	b, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("pinecone error %d: %s", resp.StatusCode, string(b))
	}
	return b, nil
}

// Helpers
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeError(w http.ResponseWriter, msg string, status int) {
	writeJSON(w, status, map[string]any{"error": msg, "code": status})
}
