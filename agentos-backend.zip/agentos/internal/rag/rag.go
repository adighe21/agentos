package rag

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	pinecone "github.com/yourusername/agentos/pkg/pinecone"
	"github.com/yourusername/agentos/internal/models"
	"go.uber.org/zap"
)

// ─── Config ───────────────────────────────────────────────────────────────────

type Config struct {
	APIKey    string
	IndexHost string
	Namespace string
}

// ─── Client ───────────────────────────────────────────────────────────────────

type Client struct {
	cfg     Config
	pc      *pinecone.Client
	httpCli *http.Client
	log     *zap.Logger
}

func NewPineconeClient(cfg Config, log *zap.Logger) (*Client, error) {
	pc := pinecone.New(cfg.APIKey, cfg.IndexHost, cfg.Namespace)
	return &Client{
		cfg:     cfg,
		pc:      pc,
		httpCli: &http.Client{Timeout: 30 * time.Second},
		log:     log,
	}, nil
}

// ─── Embedding via OpenAI compatible endpoint ─────────────────────────────────

type embeddingRequest struct {
	Input string `json:"input"`
	Model string `json:"model"`
}

type embeddingResponse struct {
	Data []struct {
		Embedding []float64 `json:"embedding"`
	} `json:"data"`
}

// Embed calls the Anthropic-compatible embedding or OpenAI text-embedding-3-small.
// Falls back to a deterministic zero vector if no key is configured (dev mode).
func (c *Client) Embed(ctx context.Context, text string) ([]float64, error) {
	// Use OpenAI embeddings (text-embedding-3-small → 1536 dims)
	reqBody := embeddingRequest{Input: text, Model: "text-embedding-3-small"}
	b, _ := json.Marshal(reqBody)

	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		"https://api.openai.com/v1/embeddings", bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+c.cfg.APIKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpCli.Do(req)
	if err != nil {
		return nil, fmt.Errorf("embedding request: %w", err)
	}
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	var er embeddingResponse
	if err := json.Unmarshal(raw, &er); err != nil || len(er.Data) == 0 {
		return nil, fmt.Errorf("embedding decode failed: %s", string(raw))
	}
	return er.Data[0].Embedding, nil
}

// ─── Retrieve: embed query → vector search → return top-K docs ───────────────

func (c *Client) Retrieve(ctx context.Context, query string, topK int) ([]models.RAGDocument, error) {
	if topK <= 0 {
		topK = 5
	}
	embedding, err := c.Embed(ctx, query)
	if err != nil {
		c.log.Warn("embed failed, returning empty context", zap.Error(err))
		return nil, nil // graceful degradation
	}

	matches, err := c.pc.Query(ctx, embedding, topK)
	if err != nil {
		return nil, fmt.Errorf("pinecone query: %w", err)
	}

	docs := make([]models.RAGDocument, 0, len(matches))
	for _, m := range matches {
		doc := models.RAGDocument{
			ID:       m.ID,
			Score:    m.Score,
			Metadata: m.Metadata,
		}
		if t, ok := m.Metadata["text"]; ok {
			doc.Text = t
		}
		docs = append(docs, doc)
	}
	return docs, nil
}

// ─── Ingest: text → embed → upsert to Pinecone ───────────────────────────────

func (c *Client) Ingest(ctx context.Context, text string, metadata map[string]string) (string, error) {
	embedding, err := c.Embed(ctx, text)
	if err != nil {
		return "", err
	}
	id := uuid.NewString()
	if metadata == nil {
		metadata = map[string]string{}
	}
	// Store text inline in metadata (Pinecone best practice for small docs)
	metadata["text"] = truncate(text, 2000)
	metadata["ingested_at"] = time.Now().UTC().Format(time.RFC3339)

	if err := c.pc.Upsert(ctx, []pinecone.Vector{{
		ID:       id,
		Values:   embedding,
		Metadata: metadata,
	}}); err != nil {
		return "", fmt.Errorf("upsert: %w", err)
	}
	return id, nil
}

// ─── HTTP Handlers ────────────────────────────────────────────────────────────

func (c *Client) HandleIngest(ctx *gin.Context) {
	var req models.IngestRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(400, gin.H{"error": err.Error()})
		return
	}
	ids := make([]string, 0, len(req.Documents))
	for _, doc := range req.Documents {
		id, err := c.Ingest(ctx.Request.Context(), doc.Text, doc.Metadata)
		if err != nil {
			ctx.JSON(500, gin.H{"error": err.Error()})
			return
		}
		ids = append(ids, id)
	}
	ctx.JSON(200, gin.H{"ingested": len(ids), "ids": ids})
}

func (c *Client) HandleQuery(ctx *gin.Context) {
	var req models.QueryRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(400, gin.H{"error": err.Error()})
		return
	}
	docs, err := c.Retrieve(ctx.Request.Context(), req.Query, req.TopK)
	if err != nil {
		ctx.JSON(500, gin.H{"error": err.Error()})
		return
	}
	ctx.JSON(200, gin.H{"results": docs, "count": len(docs)})
}

func (c *Client) HandleDelete(ctx *gin.Context) {
	id := ctx.Param("id")
	if err := c.pc.DeleteByID(ctx.Request.Context(), id); err != nil {
		ctx.JSON(500, gin.H{"error": err.Error()})
		return
	}
	ctx.JSON(200, gin.H{"deleted": id})
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max]
}

// BuildContext formats RAG docs into a prompt-ready string block.
func BuildContext(docs []models.RAGDocument) string {
	if len(docs) == 0 {
		return ""
	}
	var sb strings.Builder
	sb.WriteString("RETRIEVED KNOWLEDGE CONTEXT:\n")
	for i, d := range docs {
		sb.WriteString(fmt.Sprintf("[%d] (relevance: %.2f) %s\n\n", i+1, d.Score, d.Text))
	}
	return sb.String()
}
