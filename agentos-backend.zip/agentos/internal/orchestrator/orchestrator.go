package orchestrator

import (
	"context"
	"fmt"
	"net/http"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/yourusername/agentos/internal/agents"
	"github.com/yourusername/agentos/internal/models"
	"github.com/yourusername/agentos/internal/rag"
	"github.com/yourusername/agentos/pkg/llm"
	"go.uber.org/zap"
)

// ─── Config ───────────────────────────────────────────────────────────────────

type Config struct {
	AnthropicKey string
	OpenAIKey    string
	MaxWorkers   int
}

// ─── Orchestrator ─────────────────────────────────────────────────────────────

type Orchestrator struct {
	cfg       Config
	llm       *llm.AnthropicClient
	rag       *rag.Client
	log       *zap.Logger
	tasks     sync.Map // map[string]*models.Task
	workflows sync.Map // map[string]*models.Workflow
	sem       chan struct{}
	wg        sync.WaitGroup
}

func New(cfg Config, ragClient *rag.Client, log *zap.Logger) *Orchestrator {
	if cfg.MaxWorkers <= 0 {
		cfg.MaxWorkers = 8
	}
	return &Orchestrator{
		cfg: cfg,
		llm: llm.NewAnthropicClient(cfg.AnthropicKey),
		rag: ragClient,
		log: log,
		sem: make(chan struct{}, cfg.MaxWorkers),
	}
}

func (o *Orchestrator) Shutdown() {
	o.wg.Wait()
}

// ─── Single Agent Run ─────────────────────────────────────────────────────────

func (o *Orchestrator) HandleRunAgent(c *gin.Context) {
	var req models.RunAgentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	task := &models.Task{
		ID:        uuid.NewString(),
		AgentType: req.AgentType,
		Input:     req.Input,
		Status:    models.TaskPending,
		Metadata:  req.Metadata,
		CreatedAt: time.Now().UTC(),
		UpdatedAt: time.Now().UTC(),
	}
	o.tasks.Store(task.ID, task)

	// Run async
	o.wg.Add(1)
	go o.executeTask(context.Background(), task, req.UseRAG)

	c.JSON(http.StatusAccepted, gin.H{
		"task_id": task.ID,
		"status":  task.Status,
		"message": "task queued",
	})
}

func (o *Orchestrator) HandleTaskStatus(c *gin.Context) {
	taskID := c.Param("taskID")
	val, ok := o.tasks.Load(taskID)
	if !ok {
		c.JSON(http.StatusNotFound, gin.H{"error": "task not found"})
		return
	}
	c.JSON(http.StatusOK, val.(*models.Task))
}

func (o *Orchestrator) HandleListAgents(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"agents": agents.List()})
}

// ─── Workflow (multi-agent chain) ─────────────────────────────────────────────

func (o *Orchestrator) HandleCreateWorkflow(c *gin.Context) {
	var req models.CreateWorkflowRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if len(req.Steps) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "workflow must have at least one step"})
		return
	}

	wf := &models.Workflow{
		ID:          uuid.NewString(),
		Name:        req.Name,
		Description: req.Description,
		Steps:       req.Steps,
		Input:       req.Input,
		Status:      models.WorkflowPending,
		CreatedAt:   time.Now().UTC(),
		UpdatedAt:   time.Now().UTC(),
	}
	o.workflows.Store(wf.ID, wf)

	o.wg.Add(1)
	go o.executeWorkflow(context.Background(), wf)

	c.JSON(http.StatusAccepted, gin.H{
		"workflow_id": wf.ID,
		"status":      wf.Status,
		"steps":       len(wf.Steps),
	})
}

func (o *Orchestrator) HandleGetWorkflow(c *gin.Context) {
	id := c.Param("id")
	val, ok := o.workflows.Load(id)
	if !ok {
		c.JSON(http.StatusNotFound, gin.H{"error": "workflow not found"})
		return
	}
	c.JSON(http.StatusOK, val.(*models.Workflow))
}

func (o *Orchestrator) HandleListWorkflows(c *gin.Context) {
	var wfs []*models.Workflow
	o.workflows.Range(func(_, v interface{}) bool {
		wfs = append(wfs, v.(*models.Workflow))
		return true
	})
	c.JSON(http.StatusOK, gin.H{"workflows": wfs, "count": len(wfs)})
}

// ─── Internal execution ───────────────────────────────────────────────────────

func (o *Orchestrator) executeTask(ctx context.Context, task *models.Task, useRAG bool) {
	defer o.wg.Done()
	o.sem <- struct{}{}
	defer func() { <-o.sem }()

	start := time.Now()
	task.Status = models.TaskRunning
	task.UpdatedAt = time.Now().UTC()
	o.tasks.Store(task.ID, task)

	o.log.Info("executing task",
		zap.String("task_id", task.ID),
		zap.String("agent", string(task.AgentType)),
	)

	// RAG retrieval
	var ragContext string
	if useRAG && o.rag != nil {
		docs, err := o.rag.Retrieve(ctx, task.Input, 5)
		if err != nil {
			o.log.Warn("RAG retrieve failed", zap.Error(err))
		} else {
			task.Context = docs
			ragContext = rag.BuildContext(docs)
		}
	}

	// Get agent runner
	runner, err := agents.Get(task.AgentType)
	if err != nil {
		o.failTask(task, err.Error())
		return
	}

	// Execute
	result, err := runner.Run(ctx, task, ragContext, o.llm)
	if err != nil {
		o.failTask(task, err.Error())
		return
	}

	now := time.Now().UTC()
	task.Status = models.TaskCompleted
	task.Result = result
	task.CompletedAt = &now
	task.LatencyMs = time.Since(start).Milliseconds()
	task.UpdatedAt = now
	o.tasks.Store(task.ID, task)

	o.log.Info("task completed",
		zap.String("task_id", task.ID),
		zap.Int64("latency_ms", task.LatencyMs),
	)
}

func (o *Orchestrator) executeWorkflow(ctx context.Context, wf *models.Workflow) {
	defer o.wg.Done()

	wf.Status = models.WorkflowRunning
	wf.UpdatedAt = time.Now().UTC()
	o.workflows.Store(wf.ID, wf)

	o.log.Info("executing workflow",
		zap.String("workflow_id", wf.ID),
		zap.Int("steps", len(wf.Steps)),
	)

	currentInput := wf.Input
	var completedTasks []*models.Task

	for i, step := range wf.Steps {
		task := &models.Task{
			ID:         uuid.NewString(),
			WorkflowID: wf.ID,
			AgentType:  step.AgentType,
			Input:      currentInput,
			Status:     models.TaskPending,
			CreatedAt:  time.Now().UTC(),
			UpdatedAt:  time.Now().UTC(),
		}
		o.tasks.Store(task.ID, task)

		o.log.Info("workflow step",
			zap.String("workflow_id", wf.ID),
			zap.Int("step", i+1),
			zap.String("agent", string(step.AgentType)),
		)

		// Execute synchronously within workflow (chain output → next input)
		internalTask := &models.Task{
			ID:        task.ID,
			AgentType: task.AgentType,
			Input:     currentInput,
		}
		
		done := make(chan struct{})
		o.wg.Add(1)
		go func() {
			o.executeTask(ctx, internalTask, true)
			close(done)
		}()
		<-done

		if internalTask.Status == models.TaskFailed {
			wf.Status = models.WorkflowFailed
			wf.Error = fmt.Sprintf("step %d (%s) failed: %s", i+1, step.AgentType, internalTask.Error)
			wf.UpdatedAt = time.Now().UTC()
			o.workflows.Store(wf.ID, wf)
			return
		}

		task.Status = internalTask.Status
		task.Result = internalTask.Result
		task.LatencyMs = internalTask.LatencyMs
		completedTasks = append(completedTasks, task)
		o.tasks.Store(task.ID, task)

		// Pass result as input to next step
		currentInput = internalTask.Result
	}

	wf.Status = models.WorkflowCompleted
	wf.Tasks = completedTasks
	wf.FinalResult = currentInput
	wf.UpdatedAt = time.Now().UTC()
	o.workflows.Store(wf.ID, wf)

	o.log.Info("workflow completed",
		zap.String("workflow_id", wf.ID),
		zap.Int("steps_completed", len(completedTasks)),
	)
}

func (o *Orchestrator) failTask(task *models.Task, errMsg string) {
	now := time.Now().UTC()
	task.Status = models.TaskFailed
	task.Error = errMsg
	task.CompletedAt = &now
	task.UpdatedAt = now
	o.tasks.Store(task.ID, task)
	o.log.Error("task failed",
		zap.String("task_id", task.ID),
		zap.String("error", errMsg),
	)
}
