package models

import "time"

type AgentType string

const (
	AgentResearch AgentType = "research"
	AgentEmail    AgentType = "email"
	AgentFinance  AgentType = "finance"
	AgentData     AgentType = "data"
	AgentMatching AgentType = "matching"
	AgentSummary  AgentType = "summarization"
)

type Agent struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Type        AgentType         `json:"type"`
	Description string            `json:"description"`
	Plugins     []string          `json:"plugins"`
	Pipeline    []string          `json:"pipeline"`
	MaxPods     int               `json:"max_pods"`
	Status      string            `json:"status"`
	Metadata    map[string]string `json:"metadata,omitempty"`
}

type TaskStatus string

const (
	TaskPending   TaskStatus = "pending"
	TaskRunning   TaskStatus = "running"
	TaskCompleted TaskStatus = "completed"
	TaskFailed    TaskStatus = "failed"
)

type Task struct {
	ID          string            `json:"id"`
	WorkflowID  string            `json:"workflow_id,omitempty"`
	AgentType   AgentType         `json:"agent_type"`
	Input       string            `json:"input"`
	Context     []RAGDocument     `json:"context,omitempty"`
	Status      TaskStatus        `json:"status"`
	Result      string            `json:"result,omitempty"`
	Error       string            `json:"error,omitempty"`
	Metadata    map[string]string `json:"metadata,omitempty"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
	CompletedAt *time.Time        `json:"completed_at,omitempty"`
	LatencyMs   int64             `json:"latency_ms,omitempty"`
}

type WorkflowStatus string

const (
	WorkflowPending   WorkflowStatus = "pending"
	WorkflowRunning   WorkflowStatus = "running"
	WorkflowCompleted WorkflowStatus = "completed"
	WorkflowFailed    WorkflowStatus = "failed"
)

type WorkflowStep struct {
	AgentType AgentType `json:"agent_type"`
	InputKey  string    `json:"input_key"`
}

type Workflow struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Steps       []WorkflowStep    `json:"steps"`
	Input       string            `json:"input"`
	Status      WorkflowStatus    `json:"status"`
	Tasks       []*Task           `json:"tasks,omitempty"`
	FinalResult string            `json:"final_result,omitempty"`
	Error       string            `json:"error,omitempty"`
	Metadata    map[string]string `json:"metadata,omitempty"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
}

type RAGDocument struct {
	ID       string            `json:"id"`
	Text     string            `json:"text"`
	Score    float64           `json:"score,omitempty"`
	Metadata map[string]string `json:"metadata,omitempty"`
}

type RunAgentRequest struct {
	AgentType AgentType         `json:"agent_type" binding:"required"`
	Input     string            `json:"input" binding:"required"`
	UseRAG    bool              `json:"use_rag"`
	Metadata  map[string]string `json:"metadata,omitempty"`
}

type CreateWorkflowRequest struct {
	Name        string         `json:"name" binding:"required"`
	Description string         `json:"description"`
	Input       string         `json:"input" binding:"required"`
	Steps       []WorkflowStep `json:"steps" binding:"required"`
}

type IngestRequest struct {
	Documents []struct {
		Text     string            `json:"text" binding:"required"`
		Metadata map[string]string `json:"metadata,omitempty"`
	} `json:"documents" binding:"required"`
}

type QueryRequest struct {
	Query   string `json:"query" binding:"required"`
	TopK    int    `json:"top_k"`
	AgentID string `json:"agent_id,omitempty"`
}
