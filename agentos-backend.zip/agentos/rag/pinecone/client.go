package pinecone

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// Client wraps Pinecone REST API v1.
type Client struct {
	apiKey    string
	indexHost string // e.g. https://my-index-abc123.svc.us-east1-gcp.pinecone.io
	http      *http.Client
}

func NewClient(apiKey, indexHost string) (*Client, error) {
	if apiKey == "" || indexHost == "" {
		return nil, fmt.Errorf("PINECONE_API_KEY and PINECONE_INDEX_HOST are required")
	}
	return &Client{
		apiKey:    apiKey,
		indexHost: indexHost,
		http:      &http.Client{Timeout: 15 * time.Second},
	}, nil
}

// ─── Query ────────────────────────────────────────────────────────────────────

type QueryRequest struct {
	Vector          []float32         `json:"vector"`
	TopK            int               `json:"topK"`
	Namespace       string            `json:"namespace,omitempty"`
	Filter          map[string]interface{} `json:"filter,omitempty"`
	IncludeMetadata bool              `json:"includeMetadata"`
	IncludeValues   bool              `json:"includeValues"`
}

type QueryResponse struct {
	Matches []Match `json:"matches"`
}

type Match struct {
	ID       string            `json:"id"`
	Score    float32           `json:"score"`
	Metadata map[string]string `json:"metadata"`
	Values   []float32         `json:"values,omitempty"`
}

func (c *Client) Query(req QueryRequest) (*QueryResponse, error) {
	var out QueryResponse
	err := c.post("/query", req, &out)
	return &out, err
}

// ─── Upsert ───────────────────────────────────────────────────────────────────

type Vector struct {
	ID        string            `json:"id"`
	Values    []float32         `json:"values"`
	Metadata  map[string]string `json:"metadata,omitempty"`
	Namespace string            `json:"namespace,omitempty"`
}

type UpsertRequest struct {
	Vectors   []Vector `json:"vectors"`
	Namespace string   `json:"namespace,omitempty"`
}

type UpsertResponse struct {
	UpsertedCount int `json:"upsertedCount"`
}

func (c *Client) Upsert(req UpsertRequest) (*UpsertResponse, error) {
	var out UpsertResponse
	err := c.post("/vectors/upsert", req, &out)
	return &out, err
}

// ─── Delete ───────────────────────────────────────────────────────────────────

type DeleteRequest struct {
	IDs       []string `json:"ids"`
	Namespace string   `json:"namespace,omitempty"`
	DeleteAll bool     `json:"deleteAll,omitempty"`
}

func (c *Client) Delete(req DeleteRequest) error {
	return c.post("/vectors/delete", req, nil)
}

// ─── Stats ────────────────────────────────────────────────────────────────────

type StatsResponse struct {
	Namespaces       map[string]NamespaceStat `json:"namespaces"`
	Dimension        int                      `json:"dimension"`
	IndexFullness    float64                  `json:"indexFullness"`
	TotalVectorCount int                      `json:"totalVectorCount"`
}

type NamespaceStat struct {
	VectorCount int `json:"vectorCount"`
}

func (c *Client) Stats() (*StatsResponse, error) {
	var out StatsResponse
	err := c.get("/describe_index_stats", &out)
	return &out, err
}

// ─── HTTP helpers ─────────────────────────────────────────────────────────────

func (c *Client) post(path string, body, out interface{}) error {
	b, err := json.Marshal(body)
	if err != nil {
		return err
	}
	req, err := http.NewRequest("POST", c.indexHost+path, bytes.NewBuffer(b))
	if err != nil {
		return err
	}
	req.Header.Set("Api-Key", c.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("pinecone POST %s: %w", path, err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		return fmt.Errorf("pinecone %s returned %d: %s", path, resp.StatusCode, string(raw))
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}

func (c *Client) get(path string, out interface{}) error {
	req, err := http.NewRequest("GET", c.indexHost+path, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Api-Key", c.apiKey)
	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("pinecone GET %s: %w", path, err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		return fmt.Errorf("pinecone GET %s returned %d: %s", path, resp.StatusCode, string(raw))
	}
	return json.Unmarshal(raw, out)
}
