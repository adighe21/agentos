package handlers

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/agentos/shared"
	"github.com/agentos/rag/embeddings"
	"github.com/agentos/rag/pinecone"
)

type Handler struct {
	pc  *pinecone.Client
	emb *embeddings.Client
}

func New(pc *pinecone.Client, emb *embeddings.Client) *Handler {
	return &Handler{pc: pc, emb: emb}
}

// POST /api/v1/query
// Embed the query, search Pinecone, return top-k RAGDocuments.
func (h *Handler) Query(c *gin.Context) {
	var req shared.RAGQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, shared.Fail(err.Error()))
		return
	}
	if req.TopK == 0 {
		req.TopK = 8
	}

	start := time.Now()

	vec, err := h.emb.EmbedOne(req.Query)
	if err != nil {
		shared.Log.Sugar().Errorf("embed error: %v", err)
		c.JSON(http.StatusInternalServerError, shared.Fail("embedding failed: "+err.Error()))
		return
	}

	qr, err := h.pc.Query(pinecone.QueryRequest{
		Vector:          vec,
		TopK:            req.TopK,
		Namespace:       req.Namespace,
		IncludeMetadata: true,
	})
	if err != nil {
		shared.Log.Sugar().Errorf("pinecone query error: %v", err)
		c.JSON(http.StatusInternalServerError, shared.Fail("pinecone query failed: "+err.Error()))
		return
	}

	docs := make([]shared.RAGDocument, 0, len(qr.Matches))
	for _, m := range qr.Matches {
		text := m.Metadata["text"]
		delete(m.Metadata, "text") // keep metadata clean
		docs = append(docs, shared.RAGDocument{
			ID:       m.ID,
			Text:     text,
			Score:    m.Score,
			Metadata: m.Metadata,
		})
	}

	c.JSON(http.StatusOK, shared.OK(shared.RAGQueryResponse{
		Documents: docs,
		Latency:   time.Since(start).Milliseconds(),
	}))
}

// POST /api/v1/upsert
// Embed documents and upsert into Pinecone.
func (h *Handler) Upsert(c *gin.Context) {
	var req shared.RAGUpsertRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, shared.Fail(err.Error()))
		return
	}
	if len(req.Documents) == 0 {
		c.JSON(http.StatusBadRequest, shared.Fail("no documents provided"))
		return
	}

	texts := make([]string, len(req.Documents))
	for i, d := range req.Documents {
		texts[i] = d.Text
	}

	vecs, err := h.emb.Embed(texts)
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail("embedding failed: "+err.Error()))
		return
	}

	pVectors := make([]pinecone.Vector, len(req.Documents))
	for i, doc := range req.Documents {
		id := doc.ID
		if id == "" {
			id = uuid.NewString()
		}
		meta := doc.Metadata
		if meta == nil {
			meta = map[string]string{}
		}
		meta["text"] = doc.Text // store raw text in metadata for retrieval
		pVectors[i] = pinecone.Vector{
			ID:       id,
			Values:   vecs[i],
			Metadata: meta,
		}
	}

	res, err := h.pc.Upsert(pinecone.UpsertRequest{
		Vectors:   pVectors,
		Namespace: req.Namespace,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail("upsert failed: "+err.Error()))
		return
	}

	c.JSON(http.StatusOK, shared.OK(gin.H{
		"upserted_count": res.UpsertedCount,
		"namespace":      req.Namespace,
	}))
}

// DELETE /api/v1/vectors
func (h *Handler) Delete(c *gin.Context) {
	var body struct {
		IDs       []string `json:"ids"`
		Namespace string   `json:"namespace"`
		DeleteAll bool     `json:"delete_all"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, shared.Fail(err.Error()))
		return
	}
	if err := h.pc.Delete(pinecone.DeleteRequest{
		IDs:       body.IDs,
		Namespace: body.Namespace,
		DeleteAll: body.DeleteAll,
	}); err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail(fmt.Sprintf("delete failed: %v", err)))
		return
	}
	c.JSON(http.StatusOK, shared.OK(gin.H{"deleted": true}))
}

// GET /api/v1/stats
func (h *Handler) Stats(c *gin.Context) {
	stats, err := h.pc.Stats()
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail("stats failed: "+err.Error()))
		return
	}
	c.JSON(http.StatusOK, shared.OK(stats))
}
