package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/agentos/shared"
	"github.com/agentos/rag/handlers"
	"github.com/agentos/rag/pinecone"
	"github.com/agentos/rag/embeddings"
)

func main() {
	_ = godotenv.Load()
	shared.InitLogger("rag-service")

	port := os.Getenv("PORT")
	if port == "" {
		port = "8082"
	}

	// Init Pinecone client
	pc, err := pinecone.NewClient(
		os.Getenv("PINECONE_API_KEY"),
		os.Getenv("PINECONE_INDEX_HOST"),
	)
	if err != nil {
		log.Fatalf("pinecone init failed: %v", err)
	}

	// Init embeddings client (OpenAI text-embedding-3-small)
	emb := embeddings.NewClient(os.Getenv("OPENAI_API_KEY"))

	h := handlers.New(pc, emb)

	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(corsMiddleware())

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, shared.OK(gin.H{"service": "rag", "status": "ok"}))
	})

	api := r.Group("/api/v1")
	{
		api.POST("/query", h.Query)        // semantic search → return top-k docs
		api.POST("/upsert", h.Upsert)      // embed + upsert documents
		api.DELETE("/vectors", h.Delete)   // delete by IDs
		api.GET("/stats", h.Stats)         // index stats
	}

	shared.Log.Sugar().Infof("RAG service listening on :%s", port)
	if err := r.Run(":" + port); err != nil {
		log.Fatal(err)
	}
}

func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type,Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}
