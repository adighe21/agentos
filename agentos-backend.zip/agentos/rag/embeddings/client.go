package embeddings

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

const (
	DefaultModel = "text-embedding-3-small"
	Dimensions   = 1536
)

type Client struct {
	apiKey string
	http   *http.Client
}

func NewClient(apiKey string) *Client {
	return &Client{
		apiKey: apiKey,
		http:   &http.Client{Timeout: 30 * time.Second},
	}
}

type embedRequest struct {
	Input          []string `json:"input"`
	Model          string   `json:"model"`
	EncodingFormat string   `json:"encoding_format"`
}

type embedResponse struct {
	Data []struct {
		Embedding []float32 `json:"embedding"`
		Index     int       `json:"index"`
	} `json:"data"`
	Usage struct {
		TotalTokens int `json:"total_tokens"`
	} `json:"usage"`
}

// Embed returns one embedding vector per input string.
func (c *Client) Embed(texts []string) ([][]float32, error) {
	if len(texts) == 0 {
		return nil, nil
	}

	payload := embedRequest{
		Input:          texts,
		Model:          DefaultModel,
		EncodingFormat: "float",
	}
	b, _ := json.Marshal(payload)

	req, _ := http.NewRequest("POST", "https://api.openai.com/v1/embeddings", bytes.NewBuffer(b))
	req.Header.Set("Authorization", "Bearer "+c.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, fmt.Errorf("embed request: %w", err)
	}
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("embed API returned %d: %s", resp.StatusCode, string(raw))
	}

	var er embedResponse
	if err := json.Unmarshal(raw, &er); err != nil {
		return nil, fmt.Errorf("embed parse: %w", err)
	}

	// Sort by index (API guarantees order but let's be safe)
	result := make([][]float32, len(texts))
	for _, d := range er.Data {
		result[d.Index] = d.Embedding
	}
	return result, nil
}

// EmbedOne is a convenience wrapper for a single string.
func (c *Client) EmbedOne(text string) ([]float32, error) {
	vecs, err := c.Embed([]string{text})
	if err != nil {
		return nil, err
	}
	return vecs[0], nil
}
