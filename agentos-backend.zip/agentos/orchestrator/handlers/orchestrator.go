package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/agentos/shared"
	"github.com/agentos/orchestrator/planner"
	"github.com/agentos/orchestrator/store"
)

type Handler struct {
	planner *planner.Planner
	store   *store.RedisStore
}

func New(p *planner.Planner, s *store.RedisStore) *Handler {
	return &Handler{planner: p, store: s}
}

func (h *Handler) StartWorkflow(c *gin.Context) {
	var req shared.WorkflowRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, shared.Fail(err.Error()))
		return
	}
	if req.UserPrompt == "" {
		c.JSON(http.StatusBadRequest, shared.Fail("user_prompt is required"))
		return
	}
	workflowID := uuid.NewString()
	shared.Log.Sugar().Infof("workflow %s started: %q", workflowID, req.UserPrompt)
	tasks, err := h.planner.Plan(req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail("planning failed: "+err.Error()))
		return
	}
	wf := shared.WorkflowResponse{
		WorkflowID: workflowID,
		Tasks:      tasks,
		Status:     shared.TaskRunning,
		CreatedAt:  time.Now(),
	}
	_ = h.store.SaveWorkflow(wf)
	completed := h.planner.Execute(tasks)
	overallStatus := shared.TaskComplete
	for _, t := range completed {
		if t.Status == shared.TaskFailed {
			overallStatus = shared.TaskFailed
		}
		_ = h.store.SaveTask(t)
	}
	summary, _ := h.planner.Summarize(req.UserPrompt, completed)
	wf.Tasks = completed
	wf.Status = overallStatus
	wf.Summary = summary
	_ = h.store.SaveWorkflow(wf)
	shared.Log.Sugar().Infof("workflow %s complete, status=%s", workflowID, overallStatus)
	c.JSON(http.StatusOK, shared.OK(wf))
}

func (h *Handler) GetWorkflow(c *gin.Context) {
	wf, err := h.store.GetWorkflow(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail(err.Error()))
		return
	}
	if wf == nil {
		c.JSON(http.StatusNotFound, shared.Fail("workflow not found"))
		return
	}
	c.JSON(http.StatusOK, shared.OK(wf))
}

func (h *Handler) StreamWorkflow(c *gin.Context) {
	id := c.Param("id")
	c.Header("Content-Type", "text/event-stream")
	c.Header("Cache-Control", "no-cache")
	c.Header("Connection", "keep-alive")
	ticker := time.NewTicker(500 * time.Millisecond)
	defer ticker.Stop()
	timeout := time.After(60 * time.Second)
	for {
		select {
		case <-c.Request.Context().Done():
			return
		case <-timeout:
			fmt.Fprintf(c.Writer, "event: timeout\ndata: {}\n\n")
			c.Writer.Flush()
			return
		case <-ticker.C:
			wf, err := h.store.GetWorkflow(id)
			if err != nil || wf == nil {
				continue
			}
			b, _ := json.Marshal(wf)
			fmt.Fprintf(c.Writer, "data: %s\n\n", string(b))
			c.Writer.Flush()
			if wf.Status == shared.TaskComplete || wf.Status == shared.TaskFailed {
				fmt.Fprintf(c.Writer, "event: done\ndata: {}\n\n")
				c.Writer.Flush()
				return
			}
		}
	}
}

func (h *Handler) RunAgent(c *gin.Context) {
	agentType := shared.AgentType(c.Param("type"))
	var req struct {
		Prompt   string            `json:"prompt"`
		Metadata map[string]string `json:"metadata"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, shared.Fail(err.Error()))
		return
	}
	tasks, err := h.planner.Plan(shared.WorkflowRequest{
		UserPrompt: req.Prompt,
		Agents:     []shared.AgentType{agentType},
		Metadata:   req.Metadata,
	})
	if err != nil || len(tasks) == 0 {
		c.JSON(http.StatusInternalServerError, shared.Fail("failed to build task"))
		return
	}
	completed := h.planner.Execute(tasks)
	_ = h.store.SaveTask(completed[0])
	c.JSON(http.StatusOK, shared.OK(completed[0]))
}

func (h *Handler) ListTasks(c *gin.Context) {
	ids, err := h.store.ListTaskIDs()
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail(err.Error()))
		return
	}
	tasks := make([]shared.Task, 0, len(ids))
	for _, id := range ids {
		t, _ := h.store.GetTask(id)
		if t != nil {
			tasks = append(tasks, *t)
		}
	}
	c.JSON(http.StatusOK, shared.OK(tasks))
}

func (h *Handler) GetTask(c *gin.Context) {
	t, err := h.store.GetTask(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, shared.Fail(err.Error()))
		return
	}
	if t == nil {
		c.JSON(http.StatusNotFound, shared.Fail("task not found"))
		return
	}
	c.JSON(http.StatusOK, shared.OK(t))
}
