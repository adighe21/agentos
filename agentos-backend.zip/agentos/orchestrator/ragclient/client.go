package ragclient

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/agentos/shared"
)

type Client struct {
	baseURL string
	http    *http.Client
}

func New(baseURL string) *Client {
	if baseURL == "" {
		baseURL = "http://localhost:8082"
	}
	return &Client{
		baseURL: baseURL,
		http:    &http.Client{Timeout: 15 * time.Second},
	}
}

func (c *Client) Query(req shared.RAGQueryRequest) (*shared.RAGQueryResponse, error) {
	b, _ := json.Marshal(req)
	resp, err := c.http.Post(c.baseURL+"/api/v1/query", "application/json", bytes.NewBuffer(b))
	if err != nil {
		return nil, fmt.Errorf("rag query: %w", err)
	}
	defer resp.Body.Close()

	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("rag service returned %d: %s", resp.StatusCode, string(raw))
	}

	var apiResp struct {
		Success bool                   `json:"success"`
		Data    shared.RAGQueryResponse `json:"data"`
	}
	if err := json.Unmarshal(raw, &apiResp); err != nil {
		return nil, fmt.Errorf("rag parse: %w", err)
	}
	return &apiResp.Data, nil
}

func (c *Client) Upsert(req shared.RAGUpsertRequest) error {
	b, _ := json.Marshal(req)
	resp, err := c.http.Post(c.baseURL+"/api/v1/upsert", "application/json", bytes.NewBuffer(b))
	if err != nil {
		return fmt.Errorf("rag upsert: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		raw, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("rag upsert returned %d: %s", resp.StatusCode, string(raw))
	}
	return nil
}
