package store

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/agentos/shared"
)

const workflowTTL = 24 * time.Hour

type RedisStore struct {
	client *redis.Client
	ctx    context.Context
}

func NewRedisStore(redisURL string) (*RedisStore, error) {
	if redisURL == "" {
		redisURL = "redis://localhost:6379"
	}
	opts, err := redis.ParseURL(redisURL)
	if err != nil {
		return nil, fmt.Errorf("redis parse URL: %w", err)
	}
	client := redis.NewClient(opts)
	ctx := context.Background()
	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("redis ping failed: %w", err)
	}
	return &RedisStore{client: client, ctx: ctx}, nil
}

// ─── Workflow ─────────────────────────────────────────────────────────────────

func (s *RedisStore) SaveWorkflow(wf shared.WorkflowResponse) error {
	b, err := json.Marshal(wf)
	if err != nil {
		return err
	}
	return s.client.Set(s.ctx, workflowKey(wf.WorkflowID), b, workflowTTL).Err()
}

func (s *RedisStore) GetWorkflow(id string) (*shared.WorkflowResponse, error) {
	b, err := s.client.Get(s.ctx, workflowKey(id)).Bytes()
	if err == redis.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var wf shared.WorkflowResponse
	return &wf, json.Unmarshal(b, &wf)
}

// ─── Task ─────────────────────────────────────────────────────────────────────

func (s *RedisStore) SaveTask(task shared.Task) error {
	b, err := json.Marshal(task)
	if err != nil {
		return err
	}
	return s.client.Set(s.ctx, taskKey(task.ID), b, workflowTTL).Err()
}

func (s *RedisStore) GetTask(id string) (*shared.Task, error) {
	b, err := s.client.Get(s.ctx, taskKey(id)).Bytes()
	if err == redis.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var t shared.Task
	return &t, json.Unmarshal(b, &t)
}

func (s *RedisStore) ListTaskIDs() ([]string, error) {
	keys, err := s.client.Keys(s.ctx, "task:*").Result()
	if err != nil {
		return nil, err
	}
	ids := make([]string, len(keys))
	for i, k := range keys {
		ids[i] = k[len("task:"):]
	}
	return ids, nil
}

// ─── keys ─────────────────────────────────────────────────────────────────────

func workflowKey(id string) string { return "workflow:" + id }
func taskKey(id string) string     { return "task:" + id }
