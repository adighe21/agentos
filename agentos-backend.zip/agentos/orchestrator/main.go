package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/agentos/shared"
	"github.com/agentos/orchestrator/handlers"
	"github.com/agentos/orchestrator/planner"
	"github.com/agentos/orchestrator/ragclient"
	"github.com/agentos/orchestrator/store"
)

func main() {
	_ = godotenv.Load()
	shared.InitLogger("orchestrator")

	port := os.Getenv("PORT")
	if port == "" {
		port = "8081"
	}

	// Redis task store (Railway Redis)
	ts, err := store.NewRedisStore(os.Getenv("REDIS_URL"))
	if err != nil {
		log.Fatalf("redis init failed: %v", err)
	}

	// RAG client points to the rag-service
	rc := ragclient.New(os.Getenv("RAG_SERVICE_URL"))

	// LLM client
	llm := shared.NewLLMClient()

	// Planner: decides which agents to invoke and builds prompts
	p := planner.New(llm, rc)

	h := handlers.New(p, ts)

	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(corsMiddleware())

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, shared.OK(gin.H{"service": "orchestrator", "status": "ok"}))
	})

	api := r.Group("/api/v1")
	{
		// Core workflow endpoints
		api.POST("/workflow", h.StartWorkflow)           // submit a new multi-agent workflow
		api.GET("/workflow/:id", h.GetWorkflow)          // poll workflow status + results
		api.GET("/workflow/:id/stream", h.StreamWorkflow) // SSE stream of task updates

		// Direct single-agent call
		api.POST("/agent/:type/run", h.RunAgent)

		// Task management
		api.GET("/tasks", h.ListTasks)
		api.GET("/tasks/:id", h.GetTask)
	}

	shared.Log.Sugar().Infof("Orchestrator listening on :%s", port)
	if err := r.Run(":" + port); err != nil {
		log.Fatal(err)
	}
}

func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type,Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}
