package planner

import (
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/agentos/shared"
	"github.com/agentos/orchestrator/ragclient"
)

// Planner decides which agents handle a workflow and builds their tasks.
type Planner struct {
	llm *shared.LLMClient
	rag *ragclient.Client
}

func New(llm *shared.LLMClient, rag *ragclient.Client) *Planner {
	return &Planner{llm: llm, rag: rag}
}

// agentKeywords maps agent types to trigger keywords for auto-routing.
var agentKeywords = map[shared.AgentType][]string{
	shared.AgentResearch: {"research", "search", "find", "analyze", "summarize", "explain", "what is", "who is", "how does"},
	shared.AgentEmail:    {"email", "send", "draft", "reply", "inbox", "message"},
	shared.AgentFinance:  {"finance", "stock", "price", "market", "portfolio", "invest", "revenue", "budget"},
	shared.AgentData:     {"data", "pipeline", "etl", "dataset", "csv", "train", "model", "ml"},
	shared.AgentMatching: {"match", "recommend", "similar", "find people", "suggest"},
}

// Plan determines which agents to invoke for the given prompt.
// If agentOverrides is provided, skip auto-detection.
func (p *Planner) Plan(req shared.WorkflowRequest) ([]shared.Task, error) {
	agents := req.Agents
	if len(agents) == 0 {
		agents = p.detectAgents(req.UserPrompt)
	}
	if len(agents) == 0 {
		// Fallback: research agent handles general questions
		agents = []shared.AgentType{shared.AgentResearch}
	}

	tasks := make([]shared.Task, 0, len(agents))
	for _, agentType := range agents {
		task, err := p.buildTask(agentType, req)
		if err != nil {
			return nil, fmt.Errorf("build task for %s: %w", agentType, err)
		}
		tasks = append(tasks, task)
	}
	return tasks, nil
}

// Execute runs all tasks sequentially (or in parallel for independent agents),
// enriching each with RAG context and calling the LLM.
func (p *Planner) Execute(tasks []shared.Task) []shared.Task {
	results := make([]shared.Task, len(tasks))

	// Run tasks concurrently
	type indexed struct {
		i int
		t shared.Task
	}
	ch := make(chan indexed, len(tasks))

	for i, task := range tasks {
		go func(idx int, t shared.Task) {
			ch <- indexed{i: idx, t: p.runTask(t)}
		}(i, task)
	}

	for range tasks {
		res := <-ch
		results[res.i] = res.t
	}
	return results
}

// Summarize asks the LLM to produce a final synthesis across all task results.
func (p *Planner) Summarize(original string, tasks []shared.Task) (string, error) {
	if len(tasks) == 0 {
		return "", nil
	}
	if len(tasks) == 1 {
		return tasks[0].Result, nil
	}

	var sb strings.Builder
	sb.WriteString("You are the AgentOS orchestrator. Synthesize the following agent results into a single coherent response.\n\n")
	sb.WriteString(fmt.Sprintf("Original user request: %s\n\n", original))
	for _, t := range tasks {
		sb.WriteString(fmt.Sprintf("--- %s Agent Result ---\n%s\n\n", t.AgentType, t.Result))
	}

	resp, err := p.llm.Complete(shared.LLMRequest{
		SystemPrompt: "You are a helpful AI orchestrator. Synthesize agent outputs clearly and concisely.",
		UserPrompt:   sb.String(),
		MaxTokens:    1024,
	})
	if err != nil {
		return "", err
	}
	return resp.Content, nil
}

// ─── internals ────────────────────────────────────────────────────────────────

func (p *Planner) detectAgents(prompt string) []shared.AgentType {
	lower := strings.ToLower(prompt)
	seen := map[shared.AgentType]bool{}
	var result []shared.AgentType

	for agentType, keywords := range agentKeywords {
		for _, kw := range keywords {
			if strings.Contains(lower, kw) && !seen[agentType] {
				seen[agentType] = true
				result = append(result, agentType)
				break
			}
		}
	}
	return result
}

func (p *Planner) buildTask(agentType shared.AgentType, req shared.WorkflowRequest) (shared.Task, error) {
	return shared.Task{
		ID:        uuid.NewString(),
		AgentType: agentType,
		Prompt:    req.UserPrompt,
		Metadata:  req.Metadata,
		Status:    shared.TaskPending,
		CreatedAt: time.Now(),
	}, nil
}

func (p *Planner) runTask(task shared.Task) shared.Task {
	task.Status = shared.TaskRunning
	start := time.Now()

	// 1. Retrieve RAG context
	var ragDocs []shared.RAGDocument
	if p.rag != nil {
		resp, err := p.rag.Query(shared.RAGQueryRequest{
			Query:     task.Prompt,
			Namespace: string(task.AgentType),
			TopK:      6,
		})
		if err != nil {
			shared.Log.Sugar().Warnf("RAG query failed for task %s: %v", task.ID, err)
		} else {
			ragDocs = resp.Documents
		}
	}
	task.Context = ragDocs

	// 2. Build system prompt per agent type
	systemPrompt := agentSystemPrompt(task.AgentType)

	// 3. Call LLM
	resp, err := p.llm.Complete(shared.LLMRequest{
		SystemPrompt: systemPrompt,
		UserPrompt:   task.Prompt,
		Context:      ragDocs,
		MaxTokens:    1024,
		Model:        "claude", // default to Claude
	})

	now := time.Now()
	task.CompletedAt = &now

	if err != nil {
		task.Status = shared.TaskFailed
		task.Error = err.Error()
		shared.Log.Sugar().Errorf("task %s failed after %dms: %v", task.ID, time.Since(start).Milliseconds(), err)
		return task
	}

	task.Status = shared.TaskComplete
	task.Result = resp.Content
	shared.Log.Sugar().Infof("task %s (%s) complete in %dms, %d tokens",
		task.ID, task.AgentType, resp.Latency, resp.Tokens)
	return task
}

func agentSystemPrompt(t shared.AgentType) string {
	prompts := map[shared.AgentType]string{
		shared.AgentResearch: "You are a research agent. Search, synthesize, and summarize information accurately. " +
			"Use the provided context documents to ground your response. Cite sources where relevant.",
		shared.AgentEmail: "You are an email agent. Draft clear, professional emails based on the user's request. " +
			"Include subject line and body. Keep tone appropriate to the context.",
		shared.AgentFinance: "You are a finance agent. Analyze financial data, summarize market conditions, " +
			"and provide data-driven insights. Use provided context for grounding.",
		shared.AgentData: "You are a data pipeline agent. Help with ETL design, data cleaning, feature engineering, " +
			"and ML pipeline configuration. Provide concrete, runnable guidance.",
		shared.AgentMatching: "You are a matching and recommendation agent. Score and rank options based on semantic " +
			"similarity and user requirements. Explain your reasoning.",
	}
	if p, ok := prompts[t]; ok {
		return p
	}
	return "You are a helpful AI agent. Answer the user's request clearly and concisely."
}
